#!/bin/python3
#NOTE:type python<ICA1_python_script.py to run this in bash shell

#This code should use APIs to retrieve data from 3 primary biological databases and store it in a MySQL table which can be queried. 


#Making a connection to my personal sql db and opening the cursor to execute commands. CODE TAKEN FROM BD2_Relational_DataBases_2per.pdf, author: Simon Tomlinson.
import mysql.connector
db = mysql.connector.connect (
        host="localhost",
        user="s2268606",
        password="ghdtr73dd",
        database="s2268606_db"
        )
csr=db.cursor()


#Setting list of gene names
Subjects_symbol=["Efr3a","Suz12","Stoml1","Rif1","Tox","Gia1","Anks1b","Gm25857","Zfp640","Gm4609"]

Subjects_com_name=["EFR3 homolog A", "SUZ12 polycomb repressive complex 2 subunit", "stomatin like 1", "replication timing regulatory factor 1" , "thymocyte selection associated high mobility group box" , "Basic-leucine zipper (bZIP) transcription factor family protein" , "ankyrin repeat and sterile alpha motif domain containing 1B" , "predicted gene", "25857" , "zinc finger protein 640" , "predicted gene 4609"]


########### Entrez Pubmed ########
#This section retrieves the PMID of published materials which are obtained when searching for the gene symbol. 
#modified from BD5_BiologicalDatabases, author Simon Tomlinson. Previously modified from https://entrezpy.readthedocs.io/en/master/functions/efetch_func.html

import entrezpy.esearch.esearcher
import entrezpy.log.logger
import entrezpy.efetch.efetcher


entrezpy.log.logger.set_level('WARN')

e = entrezpy.esearch.esearcher.Esearcher("entrezpy",
                                         "s2268606@ed.ac.uk",
                                         apikey=None,
                                         apikey_var=None,
                                         threads=None,
                                         qid=None)

#I was unable to loop this code through the list of gene symbols given earlier in the code, as the following error would be given:
#200~File "/usr/lib/python3.8/threading.py", line 848, in start
#            raise RuntimeError("threads can only be started once")

analyzer_result = e.inquire({'db' : 'pubmed',
    'term' : 'Mouse [orgn] and Efr3a',
    'retmax' : '20',
    'rettype' : ('uilist')})

resTuple=analyzer_result.result.count, analyzer_result.result.uids
resString=str(resTuple[1])
print(resString)
resVals=resString[1:-1]
print(resVals)

e = entrezpy.efetch.efetcher.Efetcher("entrezpy",
                                      "s2268606@ed.ac.uk",
                                      apikey=None,
                                      apikey_var=None,
                                      threads=None,
                                      qid=None)

analyzer = e.inquire({'db' : 'pubmed',
    'id' : [resVals],
    'retmode' : 'text',
    'rettype' : 'abstract'})
print(analyzer.get_result())


#At this point, the data should be converted into a pandas df as seen in QuickGO section. See thiat section for issues on data conversion.

#################QUICKGO###################
#QuickGO, geneproduct from https://www.ebi.ac.uk/QuickGO/api/index.html#!/gene_products/geneProductSearchUsingGET


#Installing the required SQL package SQLAlchemy modified from https://www.activestate.com/resources/quick-reads/how-to-install-python-packages-using-a-script/
import sys
import subprocess

# implement pip as a subprocess:
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'sqlalchemy'])

#Creating the an SQL tables for the query entries to be uplaoded to (before combination into one table)
csr.execute('''
CREATE TABLE QuickGOtable (
    D_base VARCHAR(999),
    Id VARCHAR(999),
    Symbol VARCHAR(999),
    Name VARCHAR(999),
    Type VARCHAR(999),
    Taxon_ID VARCHAR(999),
    DatabaseSubset VARCHAR(999),
    ParentId VARCHAR(999),
    Proteome VARCHAR(999)
);
''')
db.commit()
for x in csr:
    print(x)

import requests, sys
import json
import pandas as pd
from sqlalchemy import create_engine
engine = create_engine('sqlite://', echo=False)  #code taken from https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.to_sql.html

#setting variables to be concatinated as part of url construction
requestURL_stem1 = "https://www.ebi.ac.uk/QuickGO/services/geneproduct/search?query="

#making master dataframe for QuickGO query result entry
df ={"database":[], "id":[], "symbol":[], "name":[], "synonyms":[], "type":[], "taxonId":[], "databaseSubset":[], "parentId":[], "proteome":[]}
p_df=pd.DataFrame(data=df)
print(f"The dataframe for results is:{p_df}")

#Looping through seach term gene names to get hits from GO gene products
for symbol in Subjects_symbol:
    #construct the request URL for the API to use
    requestURL = f"{requestURL_stem1}{symbol}"
    print(f"The request URL is {requestURL}")
    r = requests.get(requestURL, headers={ "Accept" : "application/json"})
    if not r.ok:
        r.raise_for_status()
        sys.exit()
    responseBody= r.text
    print(responseBody)

    #Convert the Json into a Python object
    val = json.loads(r.text)
    print("Python Object is a "+ type(val).__name__)
     separator = " "
    gr=separator.join(val.keys())
    print("Python object has keys "+ gr)

    for x in val['results']:
        print(f"The results for {symbol} search are {x}")
        df_db=x['database']
        df_id=x['id']
        df_symbol=x['symbol']
        df_name=x['name']
        df_synonyms=x['synonyms']
        df_type=x['type']
        df_tax=x['taxonId']
        df_dbSu=x['databaseSubset']
        df_PiD=x['parentId']
        df_prot=x['proteome']

        r_df= pd.DataFrame({'database':[df_db],'id':[df_id],'symbol':[df_symbol],'name':[df_name],'synonyms':[df_synonyms],'type':[df_type],'taxonId':[df_tax],'databaseSubset':[df_dbSu],'parentId':[df_PiD],'proteome':[df_prot]})
        p_df = pd.concat([p_df,r_df])

print(p_df)

#This code should transfer the pandas dataFrame to the SQL table made earlier, however, I was not able to do this and as a result, work with true data ceases here.
p_df.to_sql(name="QuickGO_table", con=engine, index=True, if_exits="append")

################ Interpro ################
#modified from https://gustavo-salazar.github.io/ProteinFamiliesTalks/InterProAPI.html?fbclid=IwAR29_rfILGLKmzDCz7iUW-CMzLBI0pEeQPeF0b6fu8bN814EEsoaOGvUJL8#/25

from urllib import request
import json

InterproAcc=["IPR039786","Q15022","Q9UBI4","Q5UIP0","O94900","Q7Z6G8","Q8CIP9"] #I was not able to identify what the appropriate query terms should be here, as anything which is not an Interpro identifier throws an HTML 404 error (no url exists). 
for gene in InterproAcc:
    IPurl1="https://www.ebi.ac.uk/interpro/api/protein/uniprot/entry/interpro/"
    url=IPurl1+gene

    req=request.Request(url)
    response = request.urlopen(req)
    encoded_response = response.read()
    decoded_response = encoded_response.decode()
    payload =json.loads(decoded_response)

    for item in payload["results"]:
        print(item["entries"])
#Similarly to above, I could not find a way to translate the resulting information into an sql database from the pandas DataFrame.



####For the purposes of this assignment, I have manually entered data from the three primary biological databases into three dummy SQL tables so that I can demonstrate how I would have manipulated such databases into a summary table (seen below) ##############

#### in mysql ####
csr.execute('''
show tables;
CREATE TABLE QuickGOtableDummy (
        D_base VARCHAR(20),
        Id VARCHAR(20),
        Symbol VARCHAR(20),
        Name VARCHAR(60),
        Type VARCHAR(100),
        Taxon_ID VARCHAR(15),
        DatabaseSubset VARCHAR(20),
        ParentId VARCHAR(50),
        Proteome VARCHAR(50),
        PRIMARY KEY (Id)
        );

CREATE TABLE InterproDummy(
        InterproAccession varchar(15),
        InterproNAme varchar(50),
        InterproSourceDatabase varchar(200),
        Interprolength int,
        InterproSourceOrganism varchar(500),
        PRIMARY KEY (InterproAccession)
        );

CREATE TABLE PubmedDummy(
        GeneQuery varchar(30),
        PMID varchar(30),
        Abstract varchar(5000),
        PRIMARY KEY (PMID)
        );


INSERT INTO
  InterproDummy (
    InterproAccession,
    InterproNAme,
    InterproSourceDatabase,
    Interprolength,
    InterproSourceOrganism
  )
VALUES
  (
    'A0A010R0Q2',
    'Protein_EFR3',
    'unreviewed',
    '1107',
    'taxId_1445577_scientificName_Colletotrichum_fioriniae_PJ7_fullName_Colletotrichum_fioriniae_PJ7'
  );

INSERT INTO
  QuickGOtableDummy(
    D_base,
    Id,
    Symbol,
    Name,
    Type,
    Taxon_ID,
    DatabaseSubset,
    ParentId,
    Proteome
  )
VALUES
  (
    'UniProtKB',
    'A0A010R0Q2',
    'EFR3A',
    'EFR3 homolog A' 'PROTEIN',
    'ankyrin repeat and sterile alpha motif domain-...',
    'PROTEIN',
    '9595.0',
    'TrEMBL' 'UniProtKB:A0A2I2Y1R8',
    'gcrpIso'
  );

INSERT INTO
  PubmedDummy(GeneQuery,PMID, Abstract)
VALUES
  (
    'Efr4a',
    '35754370',
    '1. Mol Cells. 2022 Aug 31;45(8):588-602. doi: 10.14348/molcells.2022.0044. Epub 2022
Jun 27.

RNA Binding Protein Rbms1 Enables Neuronal Differentiation and Radial Migration
during Neocortical Development by Binding and Stabilizing the RNA Message for
Efr3a.

Habib K(1), Bishayee K(1), Kang J(1), Sadra A(1), Huh SO(1).

Author information:
(1)Department of Pharmacology, College of Medicine, Institute of Natural
Medicine, Hallym University, Chuncheon 24252, Korea.

Various RNA-binding proteins (RBPs) are key components in RNA metabolism and
contribute to several neurodevelop-mental disorders. To date, only a few of such
RBPs have been characterized for their roles in neocortex development. Here, we
show that the RBP, Rbms1, is required for radial migration, polarization and
differentiation of neuronal progenitors to neurons in the neocortex development.
Rbms1 expression is highest in the early development in the developing cortex,
with its expression gradually diminishing from embryonic day 13.5 (E13.5) to
postnatal day 0 (P0). From in utero electroporation (IUE) experiments when Rbms1
levels are knocked down in neuronal progenitors, their transition from multipolar
to bipolar state is delayed and this is accompanied by a delay in radial
migration of these cells. Reduced Rbms1 levels in vivo also reduces
differentiation as evidenced by a decrease in levels of several differentiation
markers, meanwhile having no significant effects on proliferation and cell cycle
rates of these cells. As an RNA binding protein, we profiled the RNA binders of
Rbms1 by a cross-linked-RIP sequencing assay, followed by quantitative real-time
polymerase chain reaction verification and showed that Rbms1 binds and stabilizes
the mRNA for Efr3a, a signaling adapter protein. We also demonstrate that ectopic
Efr3a can recover the cells from the migration defects due to loss of Rbms1, both
in vivo and in vitro migration assays with cultured cells. These imply that one
of the functions of Rbms1 involves the stabilization of Efr3a RNA message,
required for migration and maturation of neuronal progenitors in radial migration
in the developing neocortex.

DOI: 10.14348/molcells.2022.0044
PMCID: PMC9385565
PMID: 35754370  [Indexed for MEDLINE]
'
  );
  ''')
db.commit()
for x in csr:
    print(x)

#The following block of code creates the table 'Summary' which integrates the information from three tables, relying on the gene symbol and accession numbers. The code was modified from the information at BD2_answers_SQL, author= Simon Tomlinson.
csr.execute('''
CREATE TABLE Summary AS
(SELECT PubmedDummy.*, one.* FROM
(SELECT *
FROM QuickGOtableDummy,InterproDummy
WHERE QuickGOtableDummy.Id=InterproDummy.InterproAccession)
AS one,
PubmedDummy
WHERE PubmedDummy.GeneQuery=one.Symbol)
''')
db.commit()
for x in csr:
    print(x)





#Closing the connection to my personal sql database
db.close()

#Thank you, apologies for the late submission.
