-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: B217754_db
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `InterproDummy`
--

DROP TABLE IF EXISTS `InterproDummy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InterproDummy` (
  `InterproAccession` varchar(15) NOT NULL,
  `InterproNAme` varchar(50) DEFAULT NULL,
  `InterproSourceDatabase` varchar(200) DEFAULT NULL,
  `Interprolength` int DEFAULT NULL,
  `InterproSourceOrganism` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`InterproAccession`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mart1`
--

DROP TABLE IF EXISTS `Mart1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Mart1` (
  `GeneID` varchar(20) NOT NULL,
  `Genename` varchar(50) DEFAULT NULL,
  `Start` int DEFAULT NULL,
  `End` int DEFAULT NULL,
  `Strand` char(1) DEFAULT NULL,
  PRIMARY KEY (`GeneID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PubmedDummy`
--

DROP TABLE IF EXISTS `PubmedDummy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PubmedDummy` (
  `GeneQuery` varchar(30) DEFAULT NULL,
  `PMID` varchar(30) NOT NULL,
  `Abstract` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`PMID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `QuickGOtableDummy`
--

DROP TABLE IF EXISTS `QuickGOtableDummy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QuickGOtableDummy` (
  `D_base` varchar(20) DEFAULT NULL,
  `Id` varchar(20) NOT NULL,
  `Symbol` varchar(20) DEFAULT NULL,
  `Name` varchar(60) DEFAULT NULL,
  `Type` varchar(100) DEFAULT NULL,
  `Taxon_ID` varchar(15) DEFAULT NULL,
  `DatabaseSubset` varchar(20) DEFAULT NULL,
  `ParentId` varchar(50) DEFAULT NULL,
  `Proteome` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Summary`
--

DROP TABLE IF EXISTS `Summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Summary` (
  `GeneQuery` varchar(30) DEFAULT NULL,
  `PMID` varchar(30) NOT NULL,
  `Abstract` varchar(5000) DEFAULT NULL,
  `D_base` varchar(20) DEFAULT NULL,
  `Id` varchar(20) NOT NULL,
  `Symbol` varchar(20) DEFAULT NULL,
  `Name` varchar(60) DEFAULT NULL,
  `Type` varchar(100) DEFAULT NULL,
  `Taxon_ID` varchar(15) DEFAULT NULL,
  `DatabaseSubset` varchar(20) DEFAULT NULL,
  `ParentId` varchar(50) DEFAULT NULL,
  `Proteome` varchar(50) DEFAULT NULL,
  `InterproAccession` varchar(15) NOT NULL,
  `InterproNAme` varchar(50) DEFAULT NULL,
  `InterproSourceDatabase` varchar(200) DEFAULT NULL,
  `Interprolength` int DEFAULT NULL,
  `InterproSourceOrganism` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test2`
--

DROP TABLE IF EXISTS `test2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test2` (
  `row_names` text,
  `GeneID` text,
  `Genename` text,
  `Start` bigint DEFAULT NULL,
  `End` bigint DEFAULT NULL,
  `Strand` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 15:18:02
